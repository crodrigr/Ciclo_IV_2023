const { response } = require('express');
const bcryptjs = require('bcryptjs');
const Usuario = require('../models/users');
const {generarJWT}=require('../helpers/generar-jwt');

const login = async(req, res=response)=>{
    
    const { correo, password } = req.body;

    try{
    //Validar si existe el usuario por correo
    const usuario=await Usuario.findOne({correo});
    if(!usuario){
       return res.status(400).json({
          msg:'Usuario/Password no son correctos - correo'
       });
    }
    //Validar si el usuario esta activo
    if(!usuario.estado){
        return res.status(400).json({
            msg:'Usuario/Password no son correctos - estado:false'
        });
    }
    //Validar si la contraseña es correcta
    const validPassword = bcryptjs.compareSync(password,usuario.password);
    if(!validPassword){
        return res.status(400).json({
            msg:"Usuario/Password no son correctos - password"
        });
    }
    //Generar el token
    const token= await generarJWT(usuario._id);

    
    res.json({
        usuario,
        token
    })
    
    }catch(error){
        console.log(error);
        res.status(500).json({
            msg:'Hable con el administrador del sistema.'
        });
    }
}

module.exports={ login }