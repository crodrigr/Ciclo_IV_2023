const { request, response  } = require('express');

const usuariosGet=(req,res)=>{
    res.json({
            msg:"get API -Controlador"
    }); 

}

const usuariosPost=(req=request,res)=>{

    const { pepito,id } =req.params;
    const { datos,direccion,dato3,dato4="vacio" } = req.query;
    const { nombres,apellidos,edad  } =req.body;
    
    res.json({
            msg:"post API  -Controlador",
            nombres,
            apellidos,
            edad,
            pepito,
            id,
            datos,
            direccion,
            dato3,
            dato4
    }); 

}

const usuariosPut=(req,res)=>{
    
    res.json({
            msg:"put API  -Controlador"
    }); 

}


const usuariosPatch=(req,res)=>{
    
    res.json({
            msg:"patch API  -Controlador"
    }); 

}

const usuariosDelete=(req,res)=>{
    
    res.json({
            msg:"delete API  -Controlador"
    }); 

}


module.exports={
    usuariosGet,
    usuariosPost,
    usuariosPut,
    usuariosPatch,
    usuariosDelete

}