import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClientComponent } from './client/client.component'
import { InvoiceComponent } from './invoice/invoice.component'
import {FormComponent} from './client/form/form.component'

const routes: Routes = [
  { path: 'clients', component: ClientComponent},
  { path: 'invoices', component: InvoiceComponent},
  { path: 'clients/form', component: FormComponent},
  { path: 'clients/form/:id', component: FormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
