import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable,throwError } from 'rxjs';
import { Client } from './client';
import { ClientResponse } from './clientResponse';
import { map, catchError, tap} from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  apiUrl:string='';

  constructor(private http:HttpClient,
              private router:Router) { 
             this.apiUrl=environment.apiUrl+'/api';
  }
  
  getClients(): Observable<ClientResponse>{
      return this.http.get<ClientResponse>(this.apiUrl+'/clients');
   }
   
  create(client: Client): Observable<Client>{
      return this.http.post<Client>(`${this.apiUrl}/clients`,client).pipe(
         map((response:any)=> response.client as Client),
         catchError(e=>{
             if(e.status==400){
                return throwError(()=>e);
             }
             if(e.errors.mensaje){
                console.log(e.erros.mensaje);
             }
             return throwError(()=>e);
         })
      );
  }
  
  getClientById(id:string): Observable<Client>{
    return this.http.get<Client>(`${this.apiUrl}/clients/${id}`).pipe(
      catchError(e=>{
          if(e.status!=401 && e.error.mensaje){
            this.router.navigate(['/clients']);
            console.log(e.error.mensaje);
          }
          return throwError(()=>e);
      })
    )
  }

  update(client: Client): Observable<Client>{
   return this.http.put<Client>(`${this.apiUrl}/clients/${client._id}`,client).pipe(
       catchError(e=>{
          if(e.status==400){
             return throwError(()=>e);
          }
          if(e.errors.mensaje){
             console.log(e.erros.mensaje);
          }
          return throwError(()=>e);
      })
   );
  }
  
  delete(id:string): Observable<Client>{
     return this.http.delete<Client>(`${this.apiUrl}/clients/${id}`).pipe(
         catchError(e=>{
             if(e.error.mensaje){
               console.log(e.error.mensaje);
             }
             return throwError(()=>e);
         })
     );
  }

}
