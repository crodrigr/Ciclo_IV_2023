import {Client} from './client';
export interface ClientResponse{
    total?:number;
    clients?:Client[];
}