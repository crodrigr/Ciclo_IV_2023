export interface Client{
    _id?:string;
    nombre?:string;
    apellido?:string;
    creatAt?:string;
    correo?:String;
}