import { Component, OnInit } from '@angular/core';
import { ClientService } from './client.service';
import { Client } from './client';
import { ClientResponse } from './clientResponse';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  title:string='Lista de Clientes!';
  clients: Client[]=[];

  constructor(private clienteService:ClientService) { }

  ngOnInit(): void {
    this.getClients();
  }

  getClients(): void{
    this.clienteService.getClients().subscribe({
        next:(result:ClientResponse)=>{
           console.log(result);
           const data:ClientResponse=result;
           this.clients=data.clients||[];
        },
        error:()=>{},
        complete:()=>{}
    });
  }

  delete(client:Client): void{
     this.clienteService.delete(client._id||'').subscribe({
         next:()=>{
           this.clients=this.clients.filter(x=> x!=client);
         }
     });
  }

}
