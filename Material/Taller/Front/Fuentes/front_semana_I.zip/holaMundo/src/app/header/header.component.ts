import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  login:boolean=false;

  constructor() { }
  
  
  ngOnInit(): void {
     console.log("llamado de ngOnInit");
  }

  isLoging(): void{
    
    if(this.login==true){
       this.login=false;
    }else{
      this.login=true;
    }
  
  }

}
