import { Component, OnInit } from '@angular/core';
import { Client } from '../client';
import { ClientService } from '../client.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  title:string="Crear cliente";
  client:Client={};
  errors:string[]=[];
  bottonCrater:boolean=false;

  constructor(private clientService:ClientService,
              private router:Router,
              private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
     this.getClientById();
     this.getBottonCreate();
  }

  create(): void{
     this.clientService.create(this.client).subscribe({
        next:(client:Client)=>{
            this.router.navigate(['/clients']);            
        },
        error:(err)=>{
           this.errors=err.error.erros as string[];
           console.log('Código de errores desde el back '+err.status);
           console.log(err.error.errors);
        }
     });

  }

  update(): void{
   this.clientService.update(this.client).subscribe({
      next:(client:Client)=>{
          this.router.navigate(['/clients']);            
      },
      error:(err)=>{
         this.errors=err.error.erros as string[];
         console.log('Código de errores desde el back '+err.status);
         console.log(err.error.errors);
      }
   });
  }

  getClientById(): void{
    this.activatedRoute.paramMap.subscribe(params=>{
        const id=params.get('id');
        if(id){
           this.clientService.getClientById(id).subscribe({
              next:(client:Client)=>{
                 this.client=client;
              },
              error:()=>{},
              complete:()=>{}
           });
        }
    });
  }

  getBottonCreate(): void{
   this.activatedRoute.paramMap.subscribe(params=>{
      const id=params.get('id');
      if(id){
         this.bottonCrater=false;
      }else{
         this.bottonCrater=true;
      }
   });  
  }




}
